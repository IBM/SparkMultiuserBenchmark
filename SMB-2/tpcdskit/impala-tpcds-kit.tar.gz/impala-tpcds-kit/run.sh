 ./push-bits.sh ; ./set-nodenum.sh ; ./hdfs-mkdirs.sh ; ./gen-dims.sh ; ./run-gen-facts.sh ; sleep 10; hadoop fs -du -h /user/root/tpcds*

